﻿using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;

class Program
{
    static bool ComprobarFinal(Tablero t)
    {
        int contador = 0;
        bool acabada = false;
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                if (t.Tab[i, j] == "X")
                {
                    contador++;
                }
            }
        }
        if (contador == 3)
        {
            acabada = true;
        }
        return acabada;
    }
    static void Ataque (Jugador ataca, Jugador recibe)
    {
        Console.WriteLine("Turno de " + ataca.Nombre);
        Tablero.DibujarTablero(ataca.TabOponente);
        Console.WriteLine("Elige la casilla a la que disparar:");
        string casilla = Console.ReadLine();
        int x = (int)Char.GetNumericValue(casilla[1]);
        string yProv = casilla[0].ToString().ToUpper();
        int y = 0;
        switch (yProv)
        {
            case "A":
                y = 0;
                break;
            case "B":
                y = 1;
                break;
            case "C":
                y = 2;
                break;
        }
        if (recibe.Tab.Tab[y, x] == "B")
        {
            Console.WriteLine("Has acertado");
            ataca.TabOponente.Tab[y, x] = "X";
        }
        else
        {
            Console.WriteLine("Agua!");
            ataca.TabOponente.Tab[y,x] = "A";
        }
        Tablero.DibujarTablero(ataca.TabOponente);
    }
    static void Main()
    {
        Jugador j1 = new Jugador("Jugador 1");
        Jugador j2 = new Jugador("Jugador 2");
        j1.RellenarTablero();
        j2.RellenarTablero();

        int turno = 2;
        Tablero aComprobar;


        do
        {
            Console.Clear();
            if (turno % 2 == 0)
            {
                Ataque( j1,  j2);
                aComprobar = j1.TabOponente;
            }
            else
            {
                Ataque( j2,  j1);
                aComprobar = j2.TabOponente;
            }
            turno++;
            Console.WriteLine("Pulsa cualquier tecla para continuar...");
            Console.ReadKey(true);
        } while (!ComprobarFinal(aComprobar));
        Console.ForegroundColor= ConsoleColor.Green;
        if (turno % 2 == 0)
        {
            Console.WriteLine("Ha ganado el jugador 2");
        }
        else
        {
            Console.WriteLine("Ha ganado el jugador 1");
        }
        Console.ForegroundColor = ConsoleColor.White;
    }
}