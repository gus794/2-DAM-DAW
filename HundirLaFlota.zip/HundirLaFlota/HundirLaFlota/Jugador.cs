﻿using System.Reflection.Emit;

class Jugador
{
    private string nombre;
    public string Nombre
    {
        get { return nombre;}
        set { nombre = value; }
    }

    private Tablero t = new Tablero();

    public Tablero Tab { get => t; set => t = value; }

    private Tablero tabOponente = new Tablero();
    public Tablero TabOponente { get => tabOponente; set => tabOponente = value; }
    

    public Jugador (String n)
    {
        this.Nombre = n;
        this.Tab.InicializarTablero();
        this.tabOponente.InicializarTablero();
    }
    public void RellenarTablero ()
    {
        
        for (int i = 0; i < 3; i++)
        {
            Console.Clear();
            Console.WriteLine("Rellena tu tablero, " + nombre);
            Tablero.DibujarTablero(this.Tab);
            if (!Tablero.PonerBarco(this.Tab))
            {
                Console.WriteLine("La casilla escogida ya tiene barco.");
                i--;
            }
        }
    }
}