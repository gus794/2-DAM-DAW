﻿ public class Tablero
{
    protected string[,] tab= new String[5, 5];

    public string[,] Tab
    {
        get { return tab; }
        set { tab = value; }
    }


    public void InicializarTablero ()
    {
        for (int i = 0; i< 5; i++)
        {
            for ( int j = 0; j< 5; j++)
            {
                this.tab[i, j] = " ";
            }
        }
    }
    public static void DibujarTablero(Tablero t)
    {
        Console.WriteLine("   0 1 2");
        Console.Write("A ");
        for (int i = 0; i< 3; i++){Console.Write("|" + t.tab[0, i]);}
        Console.WriteLine("|");
        Console.Write("B ");
        for (int i = 0; i < 3; i++) { Console.Write("|" + t.tab[1, i]); }
        Console.WriteLine("|");
        Console.Write("C ");
        for (int i = 0; i < 3; i++) { Console.Write("|" + t.tab[2, i]); }
        Console.WriteLine("|");
    }

    public static bool PonerBarco (Tablero t)
    {
        Console.WriteLine("Elige la casilla en la que estará el barco:");
        string casilla = Console.ReadLine();
        int x = (int)Char.GetNumericValue(casilla[1]);
        string yProv = casilla[0].ToString().ToUpper();
        int y = 0;
        switch (yProv)
        {
            case "A":
                y = 0;
            break;
            case "B":
                y = 1;
            break;
            case "C":
                y = 2;
            break;
        }
        bool colocado = false;

        if (t.tab[y,x] == " ")
        {
            t.tab[y,x] = "B";
            colocado = true;
        }
        Console.WriteLine("Pulsa cualquier tecla para continuar...");
        Console.ReadKey(true);
        return colocado;

    }
}